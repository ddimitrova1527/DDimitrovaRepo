
import java.util.Scanner;

public class Triangle {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Въведете ъгъл Алфа в градуси:");
		int alpha = sc.nextInt();
		System.out.println("Въведете ъгъл Бета в градуси:");
		int beta = sc.nextInt();
		System.out.println("Въведете ъгъл Гама в градуси:");
		int gama = sc.nextInt();
		
		int sumOfAngles = alpha + beta + gama;
		if(sumOfAngles != 180 || alpha <= 0 || beta <= 0 || gama <= 0) {
			System.out.println("Не може да се създаде триъгълник с подадените параметри");
			System.exit(0);
		}
		
		if( alpha == 60 && beta == 60 && gama == 60) {
			System.out.println("Триъгълникът е равностранен");
			System.exit(0);
		}
		if( alpha == beta || alpha == gama || beta == gama) {
			System.out.println("Триъгълникът е равнобедрен");
			System.exit(0);
		}
		if( alpha == 90 || beta == 90 || gama == 90) {
			System.out.println("Триъгълникът е правоъгълен");
			System.exit(0);
		}
		if( alpha > 90 || beta > 90 || gama > 90) {
			System.out.println("Триъгълникът е тъпоъгълен");
			System.exit(0);
		}
		if( alpha < 90 && beta < 90 && gama < 90) {
			System.out.println("Триъгълникът е равностранен");
			System.exit(0);
		}
		if( alpha != beta && alpha != gama && beta != gama) {
			System.out.println("Триъгълникът е разностранен");
			System.exit(0);
		}
		sc.close();
	}
	
}

