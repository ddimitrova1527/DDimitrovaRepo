package dataStructure;

public class forEach {

	public static void main(String[] args) {

		String[] cars = {"Volvo", "BMW", "Ford", "Mazda"};
		for (String	i : cars) {
		System.out.println(i);
		
		}
	}
	
}