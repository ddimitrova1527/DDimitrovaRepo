package dataStructure;

public class StoreNamesAndPrint {

	public static void main(String[] args) {
		String firstName = "Daniela";
		String secondName = "Stoyanova";
		String lastName = "Dimitrova";
		System.out.println(firstName + " " + secondName + " " + lastName);				

	}

}
