package dataStructure;

public class LogicalOperators {

	public static void main(String[] args) {
		int a = 3;
		int b = 6;
		int c = 3;
		if (a > b && a == c) {
			System.out.println("The if statement is true");
		} else {
			System.out.println("The if statement is false");
		}
	}
}
