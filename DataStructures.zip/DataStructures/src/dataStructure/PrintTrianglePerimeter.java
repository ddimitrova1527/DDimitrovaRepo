package dataStructure;

public class PrintTrianglePerimeter {

	public static void main(String[] args) {
		int a=5;
		int b=10;
		int c=15;
		
		int p=a+b+c;
		System.out.println(p);

	}

}
