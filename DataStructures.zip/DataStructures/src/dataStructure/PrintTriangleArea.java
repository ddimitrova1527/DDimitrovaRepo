package dataStructure;

import java.util.Scanner;

public class PrintTriangleArea {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter triangle side: ");
		double a = sc.nextDouble();
		System.out.println("Enter triangle height: ");
		double h = sc.nextDouble();
		
		double area = (a * h)/2;
		
		System.out.println("Triangle's area is: " + area);
		sc.close();

	}

}
