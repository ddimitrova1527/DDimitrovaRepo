package dataTypes;

import java.util.Iterator;

public class ArrExample {

	public static void main(String[] args) {
		
				
		/*String[] carBrands = {"Audi", "BMW", "Volvo", "Mercedes"};
		int[] evenNumbers = {2, 4, 6, 8, 10};
		double[] degrees = {0, 0.5, 1, 1.5, 2, 2.5};
		
		System.out.println(carBrands[0]);
		System.out.println(evenNumbers[2]);
		System.out.println(degrees[5]);
		
		System.out.println(carBrands.length);
		System.out.println(evenNumbers.length);
		System.out.println(degrees.length);*/
		
		String[] cars = new String[3];
		cars[0] = "Volvo";
		cars[1] = "BMW";
		cars[2] = "Mercedes";
		
		//for (int i = 0; i < cars.length; i= i+2) {
		for (int j = 0; j < cars.length - 2; j++) {
		
		System.out.println(cars[j]);
		}

	}

	}
	

		
	
