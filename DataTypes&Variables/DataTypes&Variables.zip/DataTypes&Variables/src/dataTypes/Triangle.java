package dataTypes;

import java.util.Scanner;

public class Triangle {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Въведете ъгъл �?лфа в граду�?и:");
		int alpha = sc.nextInt();
		System.out.println("Въведете ъгъл Бета в граду�?и:");
		int beta = sc.nextInt();
		System.out.println("Въведете ъгъл Гама в граду�?и:");
		int gama = sc.nextInt();
		
		int sumOfAngles = alpha + beta + gama;
		if(sumOfAngles != 180 || alpha <= 0 || beta <= 0 || gama <= 0) {
			System.out.println("�?е може да �?е �?ъздаде триъгълник �? подадените параметри");
			System.exit(0);
		}
		
		if( alpha == 60 && beta == 60 && gama == 60) {
			System.out.println("Триъгълникът е равно�?транен");
			System.exit(0);
		}
		if( alpha == beta || alpha == gama || beta == gama) {
			System.out.println("Триъгълникът е равнобедрен");
			System.exit(0);
		}
		if( alpha == 90 || beta == 90 || gama == 90) {
			System.out.println("Триъгълникът е правоъгълен");
			System.exit(0);
		}
		if( alpha > 90 || beta > 90 || gama > 90) {
			System.out.println("Триъгълникът е тъпоъгълен");
			System.exit(0);
		}
		if( alpha < 90 && beta < 90 && gama < 90) {
			System.out.println("Триъгълникът е равно�?транен");
			System.exit(0);
		}
		if( alpha != beta && alpha != gama && beta != gama) {
			System.out.println("Триъгълникът е разно�?транен");
			System.exit(0);
		}
		sc.close();
	}
	
}

