package MyJUnitPackage;

import static org.junit.jupiter.api.Assertions.*;

import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

class MyJUnitTests {
	
	WebDriver driver;
	
	@BeforeEach
	void executeBeforeTest() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://training.skillo-bg.com:4300/posts/all");
	}
	@AfterEach
	void executeAfterTest() {
		driver.close();
	}

	@Test
	void successfullLogin() {
				
		LoginPage loginPage = new LoginPage();
		loginPage.login(driver, "ddimitrova", "W@nderful77");
		Header headerMenu = new Header();
		WebElement profileLinkMenu = headerMenu.getProfileLink(driver);
		assertTrue(profileLinkMenu.isDisplayed());
	}
	@Test
	void openProfile() {
		
		LoginPage loginPage = new LoginPage();
		loginPage.login(driver, "ddimitrova", "W@nderful77");
		Header headerMenu = new Header();
		Profile profilePage = headerMenu.openProfilePage(driver);
		WebElement profileName = profilePage.getProfileName(driver);
		assertTrue(profileName.isDisplayed());
	}
	@Test
	void openNewPostFromProfile() {
		
		LoginPage loginPage = new LoginPage();
		loginPage.login(driver, "ddimitrova", "W@nderful77");
		Header headerMenu = new Header();
		Profile profilePage = headerMenu.openProfilePage(driver);
		NewPost newPostPage = profilePage.openNewPost(driver);
		
	}
}
