package MyJUnitPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Header {
	 	 WebElement getProfileLink(WebDriver driver) {
		 WebElement profileMenu = driver.findElement(By.id("nav-link-profile"));
		 return profileMenu;
	 }
	 	Profile openProfilePage(WebDriver driver) {
			WebElement profileLink = getProfileLink(driver);
			profileLink.click();
			Profile profilePage = new Profile();
			return profilePage;
		}

}
