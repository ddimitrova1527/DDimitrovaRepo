package MyJUnitPackage;

public class NewPost {
	

}
