package MyJUnitPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Profile {
	WebElement getProfileName(WebDriver driver) {
		WebElement profileName = driver.findElement(By.xpath("//h2[contains(text(),'ddimitrova')]"));
		return profileName;
	}
	WebElement getNewPostBtn(WebDriver driver) {
		WebElement newPostBtn = driver.findElement(By.xpath("(//a[@href = '/posts/create'])[2]"));
		return newPostBtn;
	}
	
	NewPost openNewPost(WebDriver driver) {
		WebElement newPostBtn = getNewPostBtn(driver);
		newPostBtn.click();
		NewPost newPostPage = new NewPost();
		return newPostPage;
	}

}
