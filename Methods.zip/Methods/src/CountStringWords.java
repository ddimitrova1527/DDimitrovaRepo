
public class CountStringWords {

	public static void main(String[] args) {
		countWords("test test ");

	}

	static void countWords(String expression) {
		String expressionModified = expression.trim();
		int asciInterval = ' ';
		int expLength = expressionModified.length();

		int wordsCounter = 1;
		
		if (expressionModified.length() == 0) {
			wordsCounter = 0;
		}

		for (int i = 0; i < expLength; i++) {
			int currAsciNumber = expressionModified.charAt(i);
			if (currAsciNumber == asciInterval) {
				wordsCounter = wordsCounter + 1;
			}

		}
		System.out.println(wordsCounter);
	}

}
