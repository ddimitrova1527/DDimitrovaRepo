/*Write a Java method to display the middle character of a string
Note :
a ) If the length of the string is odd there will be two middle
b ) If the length of the string is even there will be one middle Find biggest element of an array and print it in the
console*/

public class MiddleStringChar {

	public static void main(String[] args) {
		displayMiddleChar("daniel");
		displayMiddleChar("daniela");
		
	}
	static void displayMiddleChar(String word) {
		String phraseToDisplay = "";
		if(word.length() == 0) {
			return;
		}
		
		if(word.length() % 2 == 0) {
			int lastIndex = word.length() /2;
			phraseToDisplay = String.valueOf(word.charAt(lastIndex - 1)) + String.valueOf(word.charAt(lastIndex));
			
		}
		if(word.length() % 2 !=0) {
			int index = word.length() /2;
			phraseToDisplay = String.valueOf(word.charAt(index));
		}
		System.out.println(phraseToDisplay);
		
	}

}
