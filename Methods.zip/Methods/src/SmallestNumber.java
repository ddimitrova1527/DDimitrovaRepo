// Write a Java method to find the smallest number among three numbers.

public class SmallestNumber {

	public static void main(String[] args) {
		int smallestNumber = smallestNumber(2,1,0);
		System.out.println(smallestNumber);
			
	}
	static int smallestNumber(int a, int b, int c) {
		int smallestNumber = a;
		
		if(smallestNumber > b ) {
			smallestNumber = b;
						
		}
		if(smallestNumber > c) {
			smallestNumber = c;
		}
		return smallestNumber;
	}
	

}
