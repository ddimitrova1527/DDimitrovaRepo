// Write a Java method to compute the average of three numbers

public class AverageNumber {

	public static void main(String[] args) {
		printAverageNumber(1, 7, 3);
		
	}
	static void printAverageNumber(int a, int b, int c) {
		double average = (double) (a + b + c)/3;
		
		System.out.println(average);
		
	}

}
