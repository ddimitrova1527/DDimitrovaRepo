
/*Write a program which advises the user where to go to a vacation based on the type of the vacation 
		 * and the budget. There should be two options Beach, Mountain. If the user put a different value then the program
		 *  should print a message that there is no information about this type of vacation. 
		 *  Budgets are considered per day per person. If the budget per day for Beach type
		 * vacation is smaller than 50 then the program should advise Bulgaria as a destination, 
		 * otherwise Outside Bulgaria. If the budget per day for Mountain type vacation is smaller than 
		 * 30 then the program should advise Bulgaria as a destination, otherwise
          Outside Bulgaria.*/
		
import java.util.Scanner;

public class Vacation {

	public static void main(String[] args) {
		
					
		String vacation;
		String beach;
		String mountain;
		int budget;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter type of vacation: ");
		vacation = sc.next();
		System.out.println("Enter budget: ");
		budget = sc.nextInt();
		
		
		
		if((!vacation.equals("beach") || !vacation.equals("mountain")) && budget <  0) {
			System.out.println("There is no information about this type of vacation");
			System.exit(0);
			
		}
		
		if(vacation.equals("beach") && budget < 50) {
			System.out.println("You can select Bulgaria as sea side destination");
		} else if(vacation.equals("beach") && budget > 50) {
			System.out.println("You can select sea side destination outside Bulgaria");
		}		
		
		else if(vacation.equals("mountain") && budget < 30) {
			System.out.println("You can select Bulgaria as Mountain destination");
		} 
		else {
			System.out.println("You can select mountain destination oudside Bulgaria");
		}

	}

}
