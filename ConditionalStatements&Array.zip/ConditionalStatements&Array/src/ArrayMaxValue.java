/*Find the largest number from a given array and print it in a console. Hint: use for loop*/

public class ArrayMaxValue {

	public static void main(String[] args) {
		int array[] = {-2, 4, 5, 6};
		int maxNumber = array[0];
		
		for (int i = 0; i < array.length; i++) {
			if(maxNumber < array[i]) {
				maxNumber = array[i];
			}
			
		}
		System.out.println("Max number is: " + maxNumber);

	}

}
