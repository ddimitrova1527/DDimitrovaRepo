/*Reverse the following list using for loop list1 = [10, 20, 30, 40,*/

public class ReverseArray {

	public static void main(String[] args) {
		int[] array = new int[] {10, 20, 30, 40, 50};

		System.out.print("Reversed: ");

		for (int i = array.length - 1; i >= 0; i--) {

		  System.out.print(array[i] + " ");

		}

		// Reversed: 50 40 30 20 10

	}

}
