

public class Italian extends Person {
	public Italian(String name, String languageSpoken, String job, String nationality, String sex, String religion, String countryOfResidence, java.util.Date dateOfBirth) {
		super(name, languageSpoken, job, nationality, sex, religion, job, dateOfBirth);
	}
	
	boolean freeHands = true;
	
	protected void sayHello() {
		System.out.println("Ciao!");
	}
	
	boolean canSpeakAtTheMoment() {
		boolean canSpeak = false;
		if(this.freeHands) {
			canSpeak = true;
			
		}
		
		return canSpeak;
	}

}
