
public class Test {

	public static void main(String[] args) {
		Person ivan = new Person("English", "GB");
		Person boris = new Person("Bulgarina", "Bulgarian");
		ivan.languageSpoken = "English";
		ivan.nationality = "GB";
		ivan.job = "Developer";
		ivan.countryOfResidence = "GB";
		boris.languageSpoken = "Bulgarian";
		boris.nationality = "Bulgarian";
		boris.job = "QA";
		ivan.sex = "Male";
		ivan.religion = "Catholic";
		ivan.personalIdentificationNumber = 88052435;
		
		boris.religion = "Christian";
		ivan.sayHello("Ivan");
		boris.sayHello("Boris");
		
		System.out.println(ivan.languageSpoken);
		
        int i = 0;
        while (i < 30) {
            ivan.growOlder();
            i = i + 1;
        }

        boris.growOlder();

        System.out.println("");

       
        }
        
	}


