import java.util.Date;

/*Create class Person which has the following attributes: name, sex, religion, language spoken, job, nationality, EGN, 
 date of birth, age, country of residence. The name, language, nationality and job can be fully accessed from other 
 classes. The sex, religion and EGN can be set only once outside. The date of birth attribute is composed during the
 creation of an object based on the EGN, the age also. The Person class should have methods sayHello (), 
 celebrateEaster (), isAdult (), canTakeLoan () with the relevant parameters if any. sayHello () should print Hello 
 on the relevant language, by default is English, celebrateEaster should print if the concrete person celebrates 
 Easter based on their religion, isAdult should take in consideration the country of residence, canTakeLoan is based on the job.
Create 3 classes Child, Bulgarian and Italian which inherit Person class and using polymorphism change the 
implementation of the methods that need different behavior. Implement new methods specific only for the concrete class.
Create different objects in the main class and use their methods.*/


public class Person {
	public String name, languageSpoken, job, nationality;
	protected String sex;
	protected String religion;
	String countryOfResidence;
	Date dateOfBirth;
	protected int age;
	int year, month, day;
	
	public Person(String name, String languageSpoken, String job, String nationality, String sex, String religion, String countryOfResidence, java.util.Date date) {
		this.name = name;
		this.languageSpoken = languageSpoken;
		this.job = job;
		this.nationality = nationality;
		this.sex = sex;
		this.religion = religion;
		this.countryOfResidence = countryOfResidence;
		this.dateOfBirth = (Date) date;
		this.age = calculateAge(dateOfBirth);
				
	}
	
	public Person() {
		
	}

	private int calculateAge(Date dateOfBirth) {
		Date currentDate = new Date();
		int currentYear = currentDate.getYear();
		int dateOfBirthYear = dateOfBirth.getYear();
		if(currentYear < 1000 ) {
			currentYear = currentYear + 1900;
		}
		if(dateOfBirthYear < 1000) {
			dateOfBirthYear = dateOfBirthYear + 1900;
		}
		int age = currentYear - dateOfBirthYear;
		return age;
	}

	protected void sayHello() {
		System.out.println("Hello");
	}

	protected boolean celebrateEaster(String religion) {
		boolean celebrateEaster = false;
		if (religion.equals("Christian")) {
			celebrateEaster = true;
		}
		return celebrateEaster;
	}

	protected boolean isAdult(int age, String country) {
		boolean isAdult = false;
		if (age >= 18 && !country.equals("US")) {
			isAdult = true;
		} else if (age >= 21 && country.equals("US")) {
			isAdult = true;
		}
		return isAdult;

	}

	protected boolean canTakeLoan(String job, int age, String country) {
		boolean canTakeLoan = false;
		boolean isAdult = isAdult(age, country);
		if (isAdult && !job.trim().equals("")) {
			canTakeLoan = true;
		}
		
		return canTakeLoan;
	}

}
