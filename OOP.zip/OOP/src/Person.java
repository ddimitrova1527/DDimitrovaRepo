

/*Create class Person which has the following attributes: name, sex, religion, language spoken, job, nationality, EGN, 
 date of birth, age, country of residence. The name, language, nationality and job can be fully accessed from other 
 classes. The sex, religion and EGN can be set only once outside. The date of birth attribute is composed during the
 creation of an object based on the EGN, the age also. The Person class should have methods sayHello (), 
 celebrateEaster (), isAdult (), canTakeLoan () with the relevant parameters if any. sayHello () should print Hello 
 on the relevant language, by default is English, celebrateEaster should print if the concrete person celebrates 
 Easter based on their religion, isAdult should take in consideration the country of residence, canTakeLoan is based on the job.
Create 3 classes Child, Bulgarian and Italian which inherit Person class and using polymorphism change the 
implementation of the methods that need different behavior. Implement new methods specific only for the concrete class.
Create different objects in the main class and use their methods.*/

public class Person {
	String name;
	String sex;
	String religion;
	String languageSpoken;
	String job;
	String nationality;
	String date;
	long personalIdentificationNumber;
	int age;
	String countryOfResidence;
	boolean celebrateEaster = true;
	
	public void sayHello(String name) {
		System.out.println("Hello. I am " + name);
	}
	public Person(String name) {
		this.age = 0;
		this.name = name;
		System.out.println(this.name + ", age " + this.age + "years");
	}
	
	public Person (String languageSpoken, String nationality) {
		this.languageSpoken = languageSpoken;
		this.nationality = nationality;
		
				
	}
	
	private Person (String sex, String religion, int personalIdentificationNumber) {
		this.sex = sex;
		this.religion = religion;
		this.personalIdentificationNumber= personalIdentificationNumber;
	}
	public void growOlder() {
        if (this.age < 30) {
            this.age = this.age + 1;
        }
    }
    
    public int returnAge() {
        return this.age;
    }
    public boolean isAdult() {
        return this.age >= 18;
    }
	
}
