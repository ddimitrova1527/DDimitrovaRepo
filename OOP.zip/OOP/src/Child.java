

public class Child extends Person {
	public Child(String name, String languageSpoken, String nationality, String sex, String religion,
			String countryOfResidence, java.util.Date date) {
		super(name, languageSpoken, "", nationality, sex, religion, countryOfResidence, date);
	}
	
	String mood;
	
	protected void sayHello() {
		if(this.languageSpoken.equals("Bulgarian")) {
			System.out.println("Zdrasti!");
		} else if(this.languageSpoken.equals("Italian")) {
			System.out.println("Ciao!");
		}
	}
	
	public void setMood(String mood) {
		this.mood = mood;
		
	}
	
	public String getMood() {
		return mood;
	}
	
	boolean isMoaning() {
		boolean isMoaning = false;
		if(getMood().equals("sad") && getMood().equals("angry")) {
			isMoaning = true;
		}
		
		return isMoaning;
	}
	
}