
public class Child extends Person {
	Child(String languageSpoken, String nationality) {
		super(languageSpoken, nationality);
		this.name = name;
	}

	private String sex;
	private int age = 10;
	private long personalIdentificationNumber = 110327;
	private boolean isAdult = false;

	public void calculateAgeRange() {
		if (this.isAdult) {
			System.out.println("The child is minot");
		} else {
			System.out.println("The child is major");
		}
	}
}
