import java.util.Date;

public class Bulgarian extends Person {
	String egn;

	public Bulgarian(String name, String languageSpoken, String job, String nationality, String sex, String religion,
			String countryOfResidence, String egn) {
		this.name = name;
		this.languageSpoken = languageSpoken;
		this.job = job;
		this.nationality = nationality;
		this.sex = sex;
		this.religion = religion;
		this.countryOfResidence = countryOfResidence;
		this.dateOfBirth = calcDateOfBirth(egn);
		this.age = calculateAge(egn);
	}

	private int calculateAge(String egn) {
		int year = Integer.parseInt("19" + egn.substring(0, 1));
		Date currentDate = new Date(year, month, day);
		int age = currentDate.getYear() - year;
		return age;
	}

	private Date calcDateOfBirth(String egn) {

		Date dateOfBirth;
		int year = Integer.parseInt("19" + egn.substring(0, 1));
		int month = 0;
		int day;
		if (egn.substring(2, 2).equals("0")) {
			month = Integer.parseInt(egn.substring(3, 3));
		} else if (egn.substring(2, 2).equals("1")) {
			month = Integer.parseInt(egn.substring(2, 3));
		}
		if (egn.substring(4, 4).equals("0")) {
			day = Integer.parseInt(egn.substring(5, 5));
		} else {
			day = Integer.parseInt(egn.substring(4, 5));
		}
		dateOfBirth = new Date(year, month, day);
		return dateOfBirth;

	}

	protected void sayHello() {
		System.out.println("Zdrasti");
	}
	
	void canDoEverything() {
		System.out.println("I am the best and can do everything!");
	}
	
	void excuse() {
		System.out.println("Op!");
	}
	
	void meetGirl() {
		System.out.println("Opaaaa!");
	}
}
