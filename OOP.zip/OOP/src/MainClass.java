import java.util.Date;

public class MainClass {

	public static void main(String[] args) {
		Child child = new Child("Ivan", "Bulgarian", "BG", "M", "Christian", "BG", new Date(2010, 05, 12));
		Bulgarian bg = new Bulgarian("Dragan", "Bulgarian", "QA", "BG", "M", "Christian", "BG", "8812154650");
		Italian it = new Italian("Giovanna", "Italian", "Pizzamaker", "IT", "F", "Muslim", "IT",
				new Date(1990, 07, 12));
		child.sayHello();

	}

}
